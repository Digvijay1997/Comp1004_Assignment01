﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private String Employee_Name;
        private String Employee_Id;
        private int Totoal_Hours_worked;
        private int Total_Monthly_Sales;
        private int Sales_bonus;
    
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clearing all the Information filled !!");
            textBox1.Clear();
            textBox2.Clear(); textBox3.Clear(); textBox4.Clear(); textBox5.Clear();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = "Employee Name:";
            label3.Text = "Employee ID:";
            label4.Text = "Hours Worked:";
            label5.Text = "Total Sales:";
            label6.Text = "Sales Bonus:";
            button2.Text = "Calculate";
            button3.Text = "Print";
            button4.Text = "Clear";
        }

        private void radioButton2_CheckedChanged_1(object sender, EventArgs e)
        {
            label2.Text= "Nom de l'employé:";
            label3.Text = "ID employé:";
            label4.Text = "Heures travaillées:";
            label5.Text = "Ventes totales:";
            label6.Text = "Bonus de vente:";
            button2.Text = "Calculer";
            button3.Text = "Impression";
            button4.Text = "Clair";


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        // added Function Print
        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" This Form has been sent to Printer ");
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
        // added German language
        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {
            label2.Text = "Mitarbeitername:";
            label3.Text = "Angestellten ID:";
            label4.Text = "Arbeitsstunden:";
            label5.Text = "Gesamtumsatz:";
            label6.Text = "Verkaufs bonus:";
            button2.Text = "Drucken";
            button3.Text = "Berechnen";
            button4.Text = "Klar";
        }
    }
}
